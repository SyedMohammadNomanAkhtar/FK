package com.example.myapplication

import Crime
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*

class CrimeListViewModel : ViewModel() {
    suspend fun loadCrimes(): List<Crime> {
        return withContext(Dispatchers.Default) {
            val result = mutableListOf<Crime>()
            for (i in 0 until 100) {
                val crime = Crime(
                    id = UUID.randomUUID(),
                    title = "Crime #$i",
                    date = Date(),
                    isSolved = i % 2 == 0
                )
                result += crime
            }
            result
        }
    }
}