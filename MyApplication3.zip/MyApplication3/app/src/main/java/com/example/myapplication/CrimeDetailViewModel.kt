package com.example.myapplication

import Crime
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CrimeDetailViewModel : ViewModel() {
    private val _crime: MutableStateFlow<Crime?> = MutableStateFlow(null)
    val crime: StateFlow<Crime?> = _crime

    fun updateCrime(onUpdate: (Crime) -> Crime) {
        _crime.value = _crime.value?.let { onUpdate(it) }
    }
}